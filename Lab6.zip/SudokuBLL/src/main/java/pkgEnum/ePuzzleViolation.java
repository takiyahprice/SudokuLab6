package pkgEnum;

public enum ePuzzleViolation {

	DupRow, DupCol, DupRegion, InvalidValue, ContainsZero, MissingZero;
}